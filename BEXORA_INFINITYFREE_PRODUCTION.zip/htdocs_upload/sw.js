/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "index.html",
    "revision": "05cb7beca98d50b1a0befa4c40fc327e"
  }, {
    "url": "icon.svg",
    "revision": "ef7b8416c4ffe5e31cdf1922bc3fca57"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "8007f9233fce5104f26185a1403a8789"
  }, {
    "url": "icon-512.png",
    "revision": "e663916df9e7a534112cc26df275c983"
  }, {
    "url": "icon-192.png",
    "revision": "6cd6789099fc686e4bc68dbc82cf39aa"
  }, {
    "url": "favicon.ico",
    "revision": "6c35e2de66300d07fa77cb194fec954f"
  }, {
    "url": "favicon-32x32.png",
    "revision": "398b7a6646aee6aef9b21e102649c171"
  }, {
    "url": "favicon-16x16.png",
    "revision": "02e30bed08d4f34439faad5cb838a569"
  }, {
    "url": "bexora-logo.svg",
    "revision": "ad649331122d61b624594fefb826d2e3"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "35a7983d600e76b1308f925a6213040c"
  }, {
    "url": "sounds/04_urgent_deal.wav",
    "revision": "e8c352a88e37643c3506ab28c50bf57b"
  }, {
    "url": "sounds/03_premium_deal.wav",
    "revision": "8333c1591c48fc7f7502fb90d5954b47"
  }, {
    "url": "sounds/02_crisp_normal.wav",
    "revision": "599e04dd9b2d1a8cc0becee890517f7c"
  }, {
    "url": "sounds/01_soft_normal.wav",
    "revision": "85943c8e87add74533678a27c3d88cc1"
  }, {
    "url": "assets/index-DBGTdrf0.js",
    "revision": null
  }, {
    "url": "assets/index-CjYNnQmL.css",
    "revision": null
  }, {
    "url": "assets/aistudio/BEXORA_Digital_Asset_Marketplace_d7ac36fe.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "35a7983d600e76b1308f925a6213040c"
  }, {
    "url": "bexora-logo.svg",
    "revision": "ad649331122d61b624594fefb826d2e3"
  }, {
    "url": "favicon-16x16.png",
    "revision": "02e30bed08d4f34439faad5cb838a569"
  }, {
    "url": "favicon-32x32.png",
    "revision": "398b7a6646aee6aef9b21e102649c171"
  }, {
    "url": "favicon.ico",
    "revision": "6c35e2de66300d07fa77cb194fec954f"
  }, {
    "url": "icon-192.png",
    "revision": "6cd6789099fc686e4bc68dbc82cf39aa"
  }, {
    "url": "icon-512.png",
    "revision": "e663916df9e7a534112cc26df275c983"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "8007f9233fce5104f26185a1403a8789"
  }, {
    "url": "icon.svg",
    "revision": "ef7b8416c4ffe5e31cdf1922bc3fca57"
  }, {
    "url": "sounds/01_soft_normal.wav",
    "revision": "85943c8e87add74533678a27c3d88cc1"
  }, {
    "url": "sounds/02_crisp_normal.wav",
    "revision": "599e04dd9b2d1a8cc0becee890517f7c"
  }, {
    "url": "sounds/03_premium_deal.wav",
    "revision": "8333c1591c48fc7f7502fb90d5954b47"
  }, {
    "url": "sounds/04_urgent_deal.wav",
    "revision": "e8c352a88e37643c3506ab28c50bf57b"
  }, {
    "url": "manifest.webmanifest",
    "revision": "9712cfb4be198d1bcc8f774a8646b2f0"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api\//, /^\/__\//, /^\/firebase-messaging-sw\.js$/, /^\/vendor\/firebase\/.*\.js$/, /^\/sounds\/.*\.wav$/, /BEXORA_INFINITYFREE_PRODUCTION\.zip$/]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "bexora-google-fonts",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "bexora-gstatic-fonts",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
