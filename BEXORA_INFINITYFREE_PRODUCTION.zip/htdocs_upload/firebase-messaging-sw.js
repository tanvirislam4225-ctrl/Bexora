/* BEXORA Firebase Cloud Messaging Service Worker (Firebase Web Push) */
/* Uses public Firebase web app identifiers only — never contains private keys or secrets. */

importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyC_j2As3-45kP54cWDfzBOR69qqTR8rMr4',
  authDomain: 'responsive-dragon-tmn89.firebaseapp.com',
  projectId: 'responsive-dragon-tmn89',
  storageBucket: 'responsive-dragon-tmn89.firebasestorage.app',
  messagingSenderId: '448578956301',
  appId: '1:448578956301:web:091629c6e19eafa50ef944',
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const notificationTitle =
    (payload && payload.notification && payload.notification.title) ||
    (payload && payload.data && payload.data.title) ||
    'BEXORA Notification';
  const notificationOptions = {
    body:
      (payload && payload.notification && payload.notification.body) ||
      (payload && payload.data && payload.data.preview) ||
      'Open BEXORA to view your latest marketplace update.',
    icon: '/icon-192.png',
    badge: '/favicon-32x32.png',
    data: {
      destination: (payload && payload.data && payload.data.destination) || '',
    },
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow('/');
      }
      return undefined;
    })
  );
});
