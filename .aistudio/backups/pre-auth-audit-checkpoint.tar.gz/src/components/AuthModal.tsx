import React, { useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { AlertCircle, ExternalLink, Eye, EyeOff, KeyRound, Mail, RefreshCw, X } from 'lucide-react';
import {
  auth,
  clearPendingSignupProfile,
  db,
  DEFAULT_FIREBASE_AUTH_PROVIDERS_URL,
  detectFirebaseAuthCapabilities,
  ensureUserProfileInitialized,
  FirebaseAuthCapabilities,
  formatFirebaseAuthError,
  googleProvider,
  registerPendingSignupProfile,
  syncProactiveRefreshWithCapabilities,
} from '../lib/firebase';
import { BexoraLogo } from './Icons';
import {
  isPrivacySafeResetError,
  validateStrongPassword,
  validateUsername,
} from '../lib/marketplaceLogic';

interface AuthModalProps {
  initialMode?: 'login' | 'register' | 'forgot';
  onClose: () => void;
  onSuccess: (msg: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  initialMode = 'login',
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);

  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [recoveryTarget, setRecoveryTarget] = useState('');

  // Independent visibility controls for Password and Confirm Password
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [busy, setBusy] = useState(false);
  const [checkingCaps, setCheckingCaps] = useState(false);
  const [resetCooldownSec, setResetCooldownSec] = useState(0);
  const [capabilities, setCapabilities] = useState<FirebaseAuthCapabilities | null>(null);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  useEffect(() => {
    if (resetCooldownSec <= 0) return;
    const timer = window.setInterval(() => {
      setResetCooldownSec((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resetCooldownSec]);

  useEffect(() => {
    let active = true;
    detectFirebaseAuthCapabilities().then((caps) => {
      if (active) setCapabilities(caps);
    });
    return () => {
      active = false;
    };
  }, []);

  const handleRecheckProviders = async () => {
    setCheckingCaps(true);
    setError('');
    try {
      const caps = await detectFirebaseAuthCapabilities(true);
      setCapabilities(caps);
      if (caps.emailPasswordEnabled) {
        setInfo('Email/Password sign-in is active! You can sign in or register directly below.');
      }
    } finally {
      setCheckingCaps(false);
    }
  };

  const resetMessages = () => {
    setError('');
    setInfo('');
  };

  const emailProviderDisabled = capabilities !== null && !capabilities.emailPasswordEnabled;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    const cleanEmail = email.trim();
    if (!cleanEmail || !password) {
      setError('Enter your registered email address and password.');
      return;
    }

    setBusy(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
      syncProactiveRefreshWithCapabilities(cred.user, Boolean(capabilities?.tokenServiceEnabled));
      await ensureUserProfileInitialized(cred.user);
      onSuccess('Signed in successfully.');
      onClose();
    } catch (err) {
      setError(formatFirebaseAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    const cleanName = fullName.trim();
    if (cleanName.length < 2) {
      setError('Full name must be at least 2 characters.');
      return;
    }

    const unameCheck = validateUsername(username);
    if (!unameCheck.valid) {
      setError(unameCheck.error || 'Invalid username.');
      return;
    }

    const cleanPhone = phone.trim();
    if (!/^\+?[0-9]{8,16}$/.test(cleanPhone.replace(/[\s-]/g, ''))) {
      setError('Enter a valid phone number (8–16 digits, optional country code +880).');
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError('Enter a valid email address.');
      return;
    }

    const pwdCheck = validateStrongPassword(password);
    if (!pwdCheck.valid) {
      setError(pwdCheck.error || 'Password must be at least 8 characters with letters and numbers.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Password and Confirm Password do not match.');
      return;
    }

    setBusy(true);
    try {
      // Pre-check username availability before creating Auth credential
      const unameSnap = await getDoc(doc(db, 'usernames', unameCheck.normalized));
      if (unameSnap.exists()) {
        setError(`Username "@${unameCheck.normalized}" is already taken. Please choose another.`);
        setBusy(false);
        return;
      }

      const normalizedPhone = cleanPhone.replace(/[\s-]/g, '');
      registerPendingSignupProfile(cleanEmail, {
        displayName: cleanName,
        username: unameCheck.normalized,
        phone: normalizedPhone,
      });

      const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
      syncProactiveRefreshWithCapabilities(cred.user, Boolean(capabilities?.tokenServiceEnabled));
      await updateProfile(cred.user, { displayName: cleanName });
      await ensureUserProfileInitialized(cred.user, {
        displayName: cleanName,
        username: unameCheck.normalized,
        phone: normalizedPhone,
      });

      let verificationNote = 'Verify your email anytime in Account Settings.';
      try {
        await sendEmailVerification(cred.user, { url: window.location.origin });
        verificationNote = `Verification link sent to ${cleanEmail}! Check your Gmail inbox and Spam folder.`;
      } catch {
        // Non-blocking if rate-limited; user can trigger manual resend in Account Settings
      }

      onSuccess(`Account created! ${verificationNote}`);
      onClose();
    } catch (err) {
      clearPendingSignupProfile(cleanEmail);
      if (err instanceof Error && err.message === 'USERNAME_TAKEN') {
        setError('That username was just claimed by another user. Please choose a different username.');
      } else {
        setError(formatFirebaseAuthError(err));
      }
    } finally {
      setBusy(false);
    }
  };

  const handleGoogleSignIn = async () => {
    resetMessages();
    setBusy(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      syncProactiveRefreshWithCapabilities(cred.user, Boolean(capabilities?.tokenServiceEnabled));
      await ensureUserProfileInitialized(cred.user);
      onSuccess('Signed in with Google.');
      onClose();
    } catch (err) {
      setError(formatFirebaseAuthError(err));
    } finally {
      setBusy(false);
    }
  };

  const handlePasswordRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (resetCooldownSec > 0) return;
    resetMessages();

    const cleanTarget = recoveryTarget.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanTarget)) {
      setError('Enter your registered email address (e.g. Gmail).');
      return;
    }

    const privacySafeConfirmation =
      'If an account is registered with that email address, a secure password-reset link has been sent. Check your inbox and Spam folder.';

    setBusy(true);
    try {
      await sendPasswordResetEmail(auth, cleanTarget, { url: window.location.origin });
      setResetCooldownSec(60);
      setInfo(privacySafeConfirmation);
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      if (isPrivacySafeResetError(raw)) {
        setResetCooldownSec(60);
        setInfo(privacySafeConfirmation);
      } else {
        setError(formatFirebaseAuthError(err));
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Account authentication"
    >
      <div
        className="bx-card w-full max-w-md max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <BexoraLogo compact />
          <button
            type="button"
            onClick={onClose}
            className="bx-icon-btn !w-9 !h-9"
            aria-label="Close authentication dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Switcher */}
        {mode !== 'forgot' ? (
          <div className="grid grid-cols-2 gap-1.5 p-1.5 rounded-xl bx-soft">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                resetMessages();
              }}
              className="py-2.5 rounded-lg text-sm font-extrabold transition-colors"
              style={{
                background: mode === 'login' ? 'var(--surface)' : 'transparent',
                color: mode === 'login' ? 'var(--text)' : 'var(--text-2)',
              }}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                resetMessages();
              }}
              className="py-2.5 rounded-lg text-sm font-extrabold transition-colors"
              style={{
                background: mode === 'register' ? 'var(--surface)' : 'transparent',
                color: mode === 'register' ? 'var(--text)' : 'var(--text-2)',
              }}
            >
              Create Account
            </button>
          </div>
        ) : (
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold flex items-center gap-2">
              <KeyRound className="w-5 h-5" style={{ color: 'var(--orange)' }} />
              <span>Recover Your Password</span>
            </h2>
            <p className="bx-hint">
              Receive a secure Firebase Authentication password-reset link at your registered email
              address.
            </p>
          </div>
        )}

        {/* Google Sign-In Button — Exact Label "Connect with Google" */}
        {mode !== 'forgot' && (
          <>
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={busy}
              className="bx-btn w-full justify-center"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#EA4335"
                  d="M12 10.2v3.9h5.5c-.2 1.3-1.6 3.8-5.5 3.8-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.2.8 3.9 1.5l2.7-2.6C16.9 3.2 14.7 2.2 12 2.2 6.6 2.2 2.2 6.6 2.2 12S6.6 21.8 12 21.8c6.9 0 9.6-4.8 9.6-7.3 0-.5-.1-.9-.1-1.3H12Z"
                />
              </svg>
              <span>Connect with Google</span>
            </button>

            <div className="flex items-center gap-3 text-xs font-bold" style={{ color: 'var(--text-3)' }}>
              <div className="h-px flex-1" style={{ background: 'var(--border-soft)' }} />
              <span>OR CONTINUE WITH EMAIL</span>
              <div className="h-px flex-1" style={{ background: 'var(--border-soft)' }} />
            </div>
          </>
        )}

        {emailProviderDisabled && (
          <div
            className="p-3.5 rounded-xl text-xs font-bold leading-relaxed space-y-2 border"
            style={{
              background: 'var(--surface-2, rgba(255, 101, 0, 0.08))',
              borderColor: 'var(--orange)',
              color: 'var(--text)',
            }}
            role="note"
          >
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: 'var(--orange)' }} />
              <span>
                <strong>Email/Password provider is currently off in Firebase Console:</strong>{' '}
                Google Sign-In works immediately above. To unlock direct Email/Password sign-up,
                sign-in, and password reset on Spark (free), enable{' '}
                <strong>Authentication → Sign-in method → Email/Password</strong> in project{' '}
                <code>{capabilities?.projectId || 'responsive-dragon-tmn89'}</code>.
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <a
                href={capabilities?.firebaseAuthConsoleUrl || DEFAULT_FIREBASE_AUTH_PROVIDERS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="bx-btn bx-btn-primary bx-btn-sm inline-flex items-center gap-1.5"
              >
                <span>Open Firebase Auth</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <button
                type="button"
                onClick={handleRecheckProviders}
                disabled={checkingCaps}
                className="bx-btn bx-btn-sm inline-flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${checkingCaps ? 'animate-spin' : ''}`} />
                <span>{checkingCaps ? 'Checking…' : 'Re-check Provider Status'}</span>
              </button>
            </div>
          </div>
        )}

        {error && (
          <div
            className="p-3 rounded-xl text-xs font-bold leading-relaxed"
            style={{ background: 'var(--red-soft)', color: 'var(--red)' }}
            role="alert"
          >
            {error}
          </div>
        )}

        {info && (
          <div
            className="p-3 rounded-xl text-xs font-bold leading-relaxed"
            style={{ background: 'var(--green-soft)', color: 'var(--green)' }}
            role="status"
          >
            {info}
          </div>
        )}

        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label htmlFor="auth-login-email" className="bx-label">
                Email Address
              </label>
              <input
                id="auth-login-email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@gmail.com"
                className="bx-input"
                required
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="auth-login-password" className="bx-label !mb-0">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot');
                    setRecoveryTarget(email);
                    resetMessages();
                  }}
                  className="text-xs font-bold underline"
                  style={{ color: 'var(--orange)' }}
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <input
                  id="auth-login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="bx-input !pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg"
                  style={{ color: 'var(--text-2)' }}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={busy || emailProviderDisabled}
              className="bx-btn bx-btn-primary w-full"
            >
              {busy
                ? 'Signing in…'
                : emailProviderDisabled
                ? 'Enable Email/Password in Firebase Console'
                : 'Sign In'}
            </button>
          </form>
        )}

        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label htmlFor="reg-fullname" className="bx-label">
                Full Name
              </label>
              <input
                id="reg-fullname"
                type="text"
                autoComplete="name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Tanvir Islam"
                className="bx-input"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="reg-username" className="bx-label">
                  Unique Username
                </label>
                <input
                  id="reg-username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. tanvir_bd"
                  className="bx-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="reg-phone" className="bx-label">
                  Phone Number
                </label>
                <input
                  id="reg-phone"
                  type="tel"
                  autoComplete="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+8801XXXXXXXXX"
                  className="bx-input"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="reg-email" className="bx-label">
                Email Address
              </label>
              <input
                id="reg-email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@gmail.com"
                className="bx-input"
                required
              />
            </div>

            {/* Independent Password Field + Eye Icon */}
            <div>
              <label htmlFor="reg-password" className="bx-label">
                Password
              </label>
              <div className="relative">
                <input
                  id="reg-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters (letters & numbers)"
                  className="bx-input !pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg"
                  style={{ color: 'var(--text-2)' }}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Independent Confirm Password Field + Separate Eye Icon */}
            <div>
              <label htmlFor="reg-confirm-password" className="bx-label">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  id="reg-confirm-password"
                  type={showConfirmPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="bx-input !pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((v) => !v)}
                  aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg"
                  style={{ color: 'var(--text-2)' }}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={busy || emailProviderDisabled}
              className="bx-btn bx-btn-primary w-full"
            >
              {busy
                ? 'Creating account…'
                : emailProviderDisabled
                ? 'Enable Email/Password in Firebase Console'
                : 'Create Account'}
            </button>
          </form>
        )}

        {mode === 'forgot' && (
          <form onSubmit={handlePasswordRecovery} className="space-y-4">
            <div className="p-3 rounded-xl bx-soft flex items-center gap-2 text-xs font-bold">
              <Mail className="w-4 h-4 shrink-0" style={{ color: 'var(--orange)' }} />
              <span>Firebase Email Action Link (Gmail & Custom Domains Supported)</span>
            </div>

            <div>
              <label htmlFor="recovery-target" className="bx-label">
                Registered Email Address
              </label>
              <input
                id="recovery-target"
                type="email"
                autoComplete="email"
                value={recoveryTarget}
                onChange={(e) => setRecoveryTarget(e.target.value)}
                placeholder="you@gmail.com"
                className="bx-input"
                required
              />
            </div>

            <button
              type="submit"
              disabled={busy || emailProviderDisabled || resetCooldownSec > 0}
              className="bx-btn bx-btn-primary w-full"
            >
              {busy
                ? 'Sending reset link…'
                : emailProviderDisabled
                ? 'Enable Email/Password in Firebase Console'
                : resetCooldownSec > 0
                ? `Resend available in ${resetCooldownSec}s`
                : 'Send Password Reset Link'}
            </button>

            <button
              type="button"
              onClick={() => {
                setMode('login');
                resetMessages();
              }}
              className="bx-btn w-full"
            >
              Back to Sign In
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
