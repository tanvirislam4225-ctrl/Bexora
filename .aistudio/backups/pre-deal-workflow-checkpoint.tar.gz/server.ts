import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'MY_GEMINI_API_KEY' || key === 'YOUR_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '6mb' }));

  // 1. Health & Runtime Capabilities Endpoint
  app.get('/api/health', (_req, res) => {
    const aiConfigured = Boolean(getGeminiClient());
    res.json({
      status: 'ok',
      service: 'bexora-backend',
      timestamp: new Date().toISOString(),
      aiVerificationConfigured: aiConfigured,
      manualPaymentEnv: {
        bkash: Boolean(process.env.BKASH_PAYMENT_NUMBER?.trim()),
        nagad: Boolean(process.env.NAGAD_PAYMENT_NUMBER?.trim()),
        rocket: Boolean(process.env.ROCKET_PAYMENT_NUMBER?.trim()),
      },
      liveGatewaysEnabled: false,
      twilioRequired: false,
    });
  });

  // 2. Safe Manual Payment Destination Endpoint (No secrets exposed)
  app.get('/api/config/payments', (_req, res) => {
    res.json({
      bkashNumber: (process.env.BKASH_PAYMENT_NUMBER || '').trim(),
      nagadNumber: (process.env.NAGAD_PAYMENT_NUMBER || '').trim(),
      rocketNumber: (process.env.ROCKET_PAYMENT_NUMBER || '').trim(),
      superadminPhoneConfigured: Boolean(process.env.BEXORA_SUPERADMIN_PHONE?.trim()),
    });
  });

  // 2B. Server-Side Firebase Auth & Token Service Diagnostic + Safe Enablement Endpoints
  type ServerTokenServiceStatus =
    | 'enabled_verified'
    | 'disabled'
    | 'enablement_pending'
    | 'permission_denied'
    | 'unable_to_verify'
    | 'config_mismatch';

  let lastEnableAttemptStatus: 'none' | 'enablement_pending' | 'permission_denied' = 'none';
  let lastEnableAttemptAtMs = 0;
  let cachedSandboxServiceAccount: string | null = null;

  async function resolveSandboxServiceAccountEmail(): Promise<string> {
    if (cachedSandboxServiceAccount !== null) return cachedSandboxServiceAccount;
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 1500);
      const resp = await fetch(
        'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email',
        {
          headers: { 'Metadata-Flavor': 'Google' },
          signal: controller.signal,
        }
      );
      clearTimeout(timer);
      if (resp.ok) {
        cachedSandboxServiceAccount = (await resp.text()).trim();
        return cachedSandboxServiceAccount;
      }
    } catch {
      // Metadata server not reachable outside GCP runtime
    }
    cachedSandboxServiceAccount = '';
    return '';
  }

  async function fetchSandboxMetadataAccessToken(): Promise<string | null> {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2000);
      const resp = await fetch(
        'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',
        {
          headers: { 'Metadata-Flavor': 'Google' },
          signal: controller.signal,
        }
      );
      clearTimeout(timer);
      if (!resp.ok) return null;
      const json = (await resp.json()) as { access_token?: string };
      return typeof json.access_token === 'string' && json.access_token ? json.access_token : null;
    } catch {
      return null;
    }
  }

  function loadVerifiedFirebaseConfig() {
    const cfgPath = path.join(__dirname, 'firebase-applet-config.json');
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    const apiKey = String(cfg.apiKey || '').trim();
    const projectId = String(cfg.projectId || '').trim();
    const projectNumber = String(cfg.messagingSenderId || '448578956301').trim();
    const configValid =
      Boolean(apiKey) &&
      Boolean(projectId) &&
      projectId !== 'remixed-project-id' &&
      Boolean(projectNumber);
    const tokenServiceActivationUrl = `https://console.cloud.google.com/apis/library/securetoken.googleapis.com?project=${encodeURIComponent(
      projectId || projectNumber
    )}`;
    const iamConsoleUrl = `https://console.cloud.google.com/iam-admin/iam?project=${encodeURIComponent(
      projectId || projectNumber
    )}`;
    const firebaseAuthConsoleUrl = projectId
      ? `https://console.firebase.google.com/project/${encodeURIComponent(projectId)}/authentication/providers`
      : 'https://console.firebase.google.com/';
    return {
      apiKey,
      projectId,
      projectNumber,
      configValid,
      tokenServiceActivationUrl,
      iamConsoleUrl,
      firebaseAuthConsoleUrl,
    };
  }

  async function probeSecureTokenStatus(cfg: ReturnType<typeof loadVerifiedFirebaseConfig>): Promise<{
    status: ServerTokenServiceStatus;
    httpStatus: number | null;
    detailMessage: string;
  }> {
    if (!cfg.configValid) {
      return {
        status: 'config_mismatch',
        httpStatus: null,
        detailMessage: 'Firebase configuration is missing projectId, messagingSenderId, or apiKey.',
      };
    }

    try {
      const tokenRes = await fetch(`https://securetoken.googleapis.com/v1/token?key=${cfg.apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          grant_type: 'refresh_token',
          refresh_token: 'capability_probe_only',
        }),
      });
      const bodyText = await tokenRes.text().catch(() => '');

      if (
        tokenRes.status === 400 &&
        (bodyText.includes('INVALID_REFRESH_TOKEN') ||
          bodyText.includes('MISSING_REFRESH_TOKEN') ||
          bodyText.includes('INVALID_GRANT_TYPE'))
      ) {
        lastEnableAttemptStatus = 'none';
        return {
          status: 'enabled_verified',
          httpStatus: 400,
          detailMessage: `Token Service API (securetoken.googleapis.com) is verified active for project ${cfg.projectId} (${cfg.projectNumber}).`,
        };
      }

      if (tokenRes.status === 403) {
        if (
          bodyText.includes('SERVICE_DISABLED') ||
          bodyText.includes('securetoken.googleapis.com') ||
          bodyText.includes('Token Service API')
        ) {
          const withinPendingWindow =
            lastEnableAttemptStatus === 'enablement_pending' &&
            Date.now() - lastEnableAttemptAtMs < 5 * 60 * 1000;
          if (withinPendingWindow) {
            return {
              status: 'enablement_pending',
              httpStatus: 403,
              detailMessage:
                'Token Service API enablement succeeded in Google Cloud and is propagating (usually 1–3 minutes). Click Re-check Status shortly.',
            };
          }
          if (lastEnableAttemptStatus === 'permission_denied') {
            return {
              status: 'permission_denied',
              httpStatus: 403,
              detailMessage: `Token Service API is disabled in project ${cfg.projectId} (${cfg.projectNumber}), and the AI Studio runtime service account lacks Service Usage Admin permission to enable it automatically.`,
            };
          }
          return {
            status: 'disabled',
            httpStatus: 403,
            detailMessage: `Token Service API (securetoken.googleapis.com) is currently disabled in Google Cloud project ${cfg.projectId} (${cfg.projectNumber}).`,
          };
        }
        return {
          status: 'config_mismatch',
          httpStatus: 403,
          detailMessage:
            'API key restrictions or project mismatch blocked securetoken.googleapis.com verification.',
        };
      }

      if (bodyText.includes('API_KEY_INVALID') || bodyText.includes('PROJECT_NOT_FOUND')) {
        return {
          status: 'config_mismatch',
          httpStatus: tokenRes.status,
          detailMessage: 'Configured Firebase web API key does not match the active project.',
        };
      }

      return {
        status: 'unable_to_verify',
        httpStatus: tokenRes.status,
        detailMessage: `Could not conclusively verify Token Service API status (HTTP ${tokenRes.status}).`,
      };
    } catch {
      return {
        status: 'unable_to_verify',
        httpStatus: null,
        detailMessage: 'Network error while reaching Google Token Service endpoint.',
      };
    }
  }

  app.get('/api/auth/capabilities', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    try {
      const cfg = loadVerifiedFirebaseConfig();
      const rawHost = String(req.get('host') || 'localhost:3000');
      const hostname = rawHost.split(':')[0].toLowerCase();
      const origin = `${req.protocol}://${rawHost}`;
      const sandboxServiceAccountEmail = await resolveSandboxServiceAccountEmail();
      const firebaseAuthorizedDomainsUrl = cfg.projectId
        ? `https://console.firebase.google.com/project/${encodeURIComponent(cfg.projectId)}/authentication/settings`
        : 'https://console.firebase.google.com/';

      if (!cfg.configValid) {
        return res.json({
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          googleEnabled: false,
          googleProviderStatus: 'disabled',
          emailPasswordEnabled: false,
          emailPasswordStatus: 'disabled',
          phoneSmsEnabled: false,
          authorizedDomains: [],
          currentDomainAuthorized: false,
          tokenServiceEnabled: false,
          tokenServiceStatus: 'config_mismatch',
          tokenServiceMessage: 'Firebase configuration mismatch detected.',
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          firebaseAuthConsoleUrl: cfg.firebaseAuthConsoleUrl,
          firebaseAuthorizedDomainsUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          checkedAtMs: Date.now(),
        });
      }

      const [googleRes, pwdRes, phoneRes, projCfgRes, tokenProbe] = await Promise.all([
        fetch(`https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=${cfg.apiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ providerId: 'google.com', continueUri: origin }),
        }).catch(() => null),
        fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${cfg.apiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: 'capability-probe-nonexistent@bexora.invalid',
            password: 'probe_only_password_check',
            returnSecureToken: false,
          }),
        }).catch(() => null),
        fetch(`https://identitytoolkit.googleapis.com/v1/accounts:sendVerificationCode?key=${cfg.apiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}),
        }).catch(() => null),
        fetch(`https://identitytoolkit.googleapis.com/v1/projects?key=${cfg.apiKey}`).catch(() => null),
        probeSecureTokenStatus(cfg),
      ]);

      let googleProviderStatus: 'enabled' | 'disabled' | 'unable_to_verify' = 'unable_to_verify';
      let currentDomainAuthorized: boolean | null = null;
      if (googleRes) {
        const gText = await googleRes.text().catch(() => '');
        if (googleRes.status >= 500 || googleRes.status === 429) {
          googleProviderStatus = 'unable_to_verify';
        } else if (gText.includes('OPERATION_NOT_ALLOWED')) {
          googleProviderStatus = 'disabled';
          currentDomainAuthorized = true;
        } else if (gText.includes('UNAUTHORIZED_DOMAIN')) {
          googleProviderStatus = 'enabled';
          currentDomainAuthorized = false;
        } else if (googleRes.ok) {
          googleProviderStatus = 'enabled';
          currentDomainAuthorized = true;
        }
      }

      let emailPasswordStatus: 'enabled' | 'disabled' | 'unable_to_verify' = 'unable_to_verify';
      if (pwdRes) {
        const pwdText = await pwdRes.text().catch(() => '');
        if (pwdRes.status >= 500 || pwdRes.status === 429) {
          emailPasswordStatus = 'unable_to_verify';
        } else if (
          pwdText.includes('PASSWORD_LOGIN_DISABLED') ||
          pwdText.includes('OPERATION_NOT_ALLOWED')
        ) {
          emailPasswordStatus = 'disabled';
        } else if (
          pwdRes.ok ||
          (pwdRes.status === 400 &&
            (pwdText.includes('EMAIL_NOT_FOUND') ||
              pwdText.includes('INVALID_LOGIN_CREDENTIALS') ||
              pwdText.includes('INVALID_PASSWORD') ||
              pwdText.includes('INVALID_EMAIL') ||
              pwdText.includes('USER_DISABLED') ||
              pwdText.includes('TOO_MANY_ATTEMPTS_TRY_LATER')))
        ) {
          emailPasswordStatus = 'enabled';
        }
      }

      let phoneSmsEnabled = true;
      if (phoneRes) {
        const phoneJson = (await phoneRes.json().catch(() => ({}))) as { error?: { message?: string } };
        const phoneMsg = String(phoneJson?.error?.message || '');
        if (phoneMsg.includes('OPERATION_NOT_ALLOWED') || phoneMsg.includes('BILLING_NOT_ENABLED')) {
          phoneSmsEnabled = false;
        }
      }

      let authorizedDomains: string[] = [];
      if (projCfgRes && projCfgRes.ok) {
        const projJson = (await projCfgRes.json().catch(() => ({}))) as { authorizedDomains?: unknown };
        if (Array.isArray(projJson.authorizedDomains)) {
          authorizedDomains = projJson.authorizedDomains.filter((d): d is string => typeof d === 'string');
          if (authorizedDomains.length > 0 && hostname) {
            currentDomainAuthorized = authorizedDomains.some((d) => d.toLowerCase() === hostname);
          }
        }
      }

      return res.json({
        projectId: cfg.projectId,
        projectNumber: cfg.projectNumber,
        googleEnabled: googleProviderStatus !== 'disabled',
        googleProviderStatus,
        emailPasswordEnabled: emailPasswordStatus !== 'disabled',
        emailPasswordStatus,
        phoneSmsEnabled,
        authorizedDomains,
        currentDomainAuthorized,
        tokenServiceEnabled: tokenProbe.status === 'enabled_verified',
        tokenServiceStatus: tokenProbe.status,
        tokenServiceMessage: tokenProbe.detailMessage,
        tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
        iamConsoleUrl: cfg.iamConsoleUrl,
        firebaseAuthConsoleUrl: cfg.firebaseAuthConsoleUrl,
        firebaseAuthorizedDomainsUrl,
        sandboxServiceAccountEmail,
        requiredRole: 'roles/serviceusage.serviceUsageAdmin',
        checkedAtMs: Date.now(),
      });
    } catch {
      return res.json({
        googleEnabled: true,
        googleProviderStatus: 'unable_to_verify',
        emailPasswordEnabled: true,
        emailPasswordStatus: 'unable_to_verify',
        phoneSmsEnabled: false,
        authorizedDomains: [],
        currentDomainAuthorized: null,
        tokenServiceEnabled: false,
        tokenServiceStatus: 'unable_to_verify',
        tokenServiceMessage: 'Temporary network issue while probing Firebase Auth capabilities.',
        checkedAtMs: Date.now(),
      });
    }
  });

  app.post('/api/auth/enable-token-service', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    try {
      const cfg = loadVerifiedFirebaseConfig();
      const sandboxServiceAccountEmail = await resolveSandboxServiceAccountEmail();

      if (!cfg.configValid) {
        return res.json({
          ok: false,
          tokenServiceStatus: 'config_mismatch' as ServerTokenServiceStatus,
          tokenServiceEnabled: false,
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          firebaseAuthConsoleUrl: cfg.firebaseAuthConsoleUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          message: `Safety check blocked modification: invalid or uninitialized Firebase project configuration (${cfg.projectId || 'missing'}).`,
        });
      }

      // First verify whether securetoken.googleapis.com is already active
      const currentProbe = await probeSecureTokenStatus(cfg);
      if (currentProbe.status === 'enabled_verified') {
        return res.json({
          ok: true,
          tokenServiceStatus: 'enabled_verified' as ServerTokenServiceStatus,
          tokenServiceEnabled: true,
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          message: `Token Service API (securetoken.googleapis.com) is verified active for ${cfg.projectId} (${cfg.projectNumber}).`,
        });
      }

      // Rate-limit repeated enablement calls within 6 seconds
      if (Date.now() - lastEnableAttemptAtMs < 6000 && lastEnableAttemptStatus !== 'none') {
        return res.json({
          ok: lastEnableAttemptStatus === 'enablement_pending',
          tokenServiceStatus: lastEnableAttemptStatus as ServerTokenServiceStatus,
          tokenServiceEnabled: false,
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          message:
            lastEnableAttemptStatus === 'enablement_pending'
              ? 'Enablement request already sent and propagating in Google Cloud. Please wait ~60 seconds and click Re-check Status.'
              : `Automatic enablement requires Service Usage Admin (${sandboxServiceAccountEmail || 'runtime service account'}) on project ${cfg.projectId}, or 1-click activation in Google Cloud Console.`,
        });
      }

      lastEnableAttemptAtMs = Date.now();
      const accessToken = await fetchSandboxMetadataAccessToken();
      if (!accessToken) {
        lastEnableAttemptStatus = 'permission_denied';
        return res.json({
          ok: false,
          tokenServiceStatus: 'permission_denied' as ServerTokenServiceStatus,
          tokenServiceEnabled: false,
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          message: `No Google Cloud Service Usage credentials are attached to this server runtime. Enable Token Service API directly in Google Cloud Console for project ${cfg.projectId} (${cfg.projectNumber}).`,
        });
      }

      const enableRes = await fetch(
        `https://serviceusage.googleapis.com/v1/projects/${encodeURIComponent(
          cfg.projectId
        )}/services/securetoken.googleapis.com:enable`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            'X-Goog-User-Project': cfg.projectId,
          },
          body: JSON.stringify({}),
        }
      );

      if (enableRes.ok) {
        // Poll up to 2 times for fast propagation
        for (let attempt = 0; attempt < 2; attempt++) {
          await new Promise((r) => setTimeout(r, 1200));
          const verifyAfter = await probeSecureTokenStatus(cfg);
          if (verifyAfter.status === 'enabled_verified') {
            lastEnableAttemptStatus = 'none';
            return res.json({
              ok: true,
              tokenServiceStatus: 'enabled_verified' as ServerTokenServiceStatus,
              tokenServiceEnabled: true,
              projectId: cfg.projectId,
              projectNumber: cfg.projectNumber,
              tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
              iamConsoleUrl: cfg.iamConsoleUrl,
              sandboxServiceAccountEmail,
              requiredRole: 'roles/serviceusage.serviceUsageAdmin',
              message: `Token Service API (securetoken.googleapis.com) was enabled and verified active on ${cfg.projectId}!`,
            });
          }
        }

        lastEnableAttemptStatus = 'enablement_pending';
        return res.json({
          ok: true,
          tokenServiceStatus: 'enablement_pending' as ServerTokenServiceStatus,
          tokenServiceEnabled: false,
          projectId: cfg.projectId,
          projectNumber: cfg.projectNumber,
          tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
          iamConsoleUrl: cfg.iamConsoleUrl,
          sandboxServiceAccountEmail,
          requiredRole: 'roles/serviceusage.serviceUsageAdmin',
          message:
            'Google Cloud accepted the Token Service API enablement request. Propagation takes 1–3 minutes — click Re-check Status shortly.',
        });
      }

      lastEnableAttemptStatus = 'permission_denied';
      return res.json({
        ok: false,
        tokenServiceStatus: 'permission_denied' as ServerTokenServiceStatus,
        tokenServiceEnabled: false,
        projectId: cfg.projectId,
        projectNumber: cfg.projectNumber,
        tokenServiceActivationUrl: cfg.tokenServiceActivationUrl,
        iamConsoleUrl: cfg.iamConsoleUrl,
        firebaseAuthConsoleUrl: cfg.firebaseAuthConsoleUrl,
        sandboxServiceAccountEmail,
        requiredRole: 'roles/serviceusage.serviceUsageAdmin',
        message: sandboxServiceAccountEmail
          ? `Google Cloud IAM denied automatic enablement because ${sandboxServiceAccountEmail} lacks Service Usage Admin (roles/serviceusage.serviceUsageAdmin) on project ${cfg.projectId} (${cfg.projectNumber}). Open Cloud Console specifically for project ${cfg.projectId} (not another project) to click Enable, or link a clean self-owned Firebase project where your account holds Project Owner.`
          : `Google Cloud IAM denied automatic Service Usage enablement on project ${cfg.projectId} (${cfg.projectNumber}). Enable Token Service API directly in Google Cloud Console for project ${cfg.projectId}.`,
      });
    } catch {
      return res.json({
        ok: false,
        tokenServiceStatus: 'unable_to_verify' as ServerTokenServiceStatus,
        tokenServiceEnabled: false,
        message: 'Could not reach Google Cloud Service Usage API. Check connectivity and try again.',
      });
    }
  });

  // 3. Server-Side AI Monetization Evidence Verification Pipeline
  app.post('/api/ai/verify-evidence', async (req, res) => {
    try {
      const ai = getGeminiClient();
      if (!ai) {
        return res.status(503).json({
          available: false,
          outcome: 'human_review_required',
          summary:
            'AI screenshot analysis is not configured in this environment. Queued for manual administrator evidence review.',
          method: 'manual_queue_fallback',
        });
      }

      const { platform, claimedOptions, imageDataUrl } = req.body || {};
      if (!platform || !Array.isArray(claimedOptions) || typeof imageDataUrl !== 'string') {
        return res.status(400).json({ error: 'Missing platform, claimedOptions, or imageDataUrl.' });
      }

      const match = imageDataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,(.+)$/);
      if (!match) {
        return res.status(400).json({ error: 'Unsupported evidence image format. Use PNG, JPEG, or WebP.' });
      }

      const mimeType = match[1];
      const base64Data = match[2];

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: {
          parts: [
            { inlineData: { mimeType, data: base64Data } },
            {
              text: `Inspect this seller-submitted screenshot for a ${platform} digital asset claiming monetization programs: ${claimedOptions.join(', ')}.
Assess strictly without overclaiming:
1. Does the screenshot match ${platform}?
2. Is status text readable and showing Active/Enabled vs Eligible/In Review/Rejected?
3. Are any passwords, OTPs, or recovery codes exposed?
Remember: a screenshot alone is never direct platform API verification. Recommend 'in_review' whenever uncertain.`,
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              platformMatched: { type: Type.BOOLEAN },
              detectedState: {
                type: Type.STRING,
                description: 'One of: active_indicators, eligible_only, in_review, rejected_or_disabled, unreadable_or_unrelated',
              },
              privateDataExposed: { type: Type.BOOLEAN },
              recommendedOutcome: {
                type: Type.STRING,
                description: 'One of: human_review_required, request_new_evidence',
              },
              summary: { type: Type.STRING },
            },
            required: ['platformMatched', 'detectedState', 'privateDataExposed', 'recommendedOutcome', 'summary'],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      return res.json({
        available: true,
        method: 'ai_assessed_screenshot',
        ...parsed,
      });
    } catch (error) {
      console.error('AI evidence verification error:', error instanceof Error ? error.message : String(error));
      return res.status(502).json({
        available: false,
        outcome: 'human_review_required',
        summary: 'AI provider returned an error or timed out. Listing kept safely in pending human review.',
        method: 'error_fallback_human_review',
      });
    }
  });

  // 4. Server-Side AI Developer Chat (Admin Panel Only)
  app.post('/api/ai/developer-chat', async (req, res) => {
    try {
      const ai = getGeminiClient();
      if (!ai) {
        return res.status(503).json({
          available: false,
          reply:
            'GEMINI_API_KEY is not configured on this server. Deterministic health monitoring, proposal queue, and Emergency Stop remain active.',
        });
      }

      const { message, systemContext } = req.body || {};
      if (typeof message !== 'string' || !message.trim()) {
        return res.status(400).json({ error: 'Prompt message is required.' });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: message.slice(0, 4000),
        config: {
          systemInstruction: `You are the BEXORA Production-Safe AI Developer inside the BEXORA Admin Panel.
Follow strict safety rules:
- Never claim to auto-deploy changes to production without explicit human Approve action.
- Never weaken Firestore Security Rules or expose secrets.
- Explain root causes, affected files, risks, and staged test plans clearly in concise language for a non-technical project owner.
Current system snapshot: ${typeof systemContext === 'string' ? systemContext.slice(0, 1500) : 'Standard Firebase + React architecture'}`,
        },
      });

      return res.json({
        available: true,
        reply: response.text || 'Analysis complete.',
      });
    } catch (error) {
      console.error('AI Developer chat error:', error instanceof Error ? error.message : String(error));
      return res.status(502).json({
        available: false,
        reply: 'AI Developer service encountered a temporary error. Deterministic diagnostics remain operational.',
      });
    }
  });

  const httpServer = http.createServer(app);
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(path.join(__dirname, 'dist', 'index.html'));
  if (isProd) {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const hmrDisabled = process.env.DISABLE_HMR === 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: { server: httpServer },
        ws: hmrDisabled ? false : { server: httpServer },
        hmr: hmrDisabled ? false : { overlay: false },
        watch: hmrDisabled ? null : {},
        forwardConsole: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`BEXORA server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start BEXORA server:', err);
  process.exit(1);
});
