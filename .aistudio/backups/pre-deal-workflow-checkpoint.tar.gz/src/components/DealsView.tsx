import React, { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
} from 'firebase/firestore';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Send,
  ShieldCheck,
  Star,
} from 'lucide-react';
import {
  ChatMessageRecord,
  CurrencyCode,
  DealRecord,
  DealReportRecord,
  PrivateUser,
  PublicProfile,
  PublicSettings,
} from '../types';
import { db } from '../lib/firebase';
import {
  computeRemainingProtectionMs,
  detectSensitiveOrOffPlatformContent,
  formatMoneyFromMinor,
} from '../lib/marketplaceLogic';
import { emitUserNotification } from '../lib/notificationService';

const ProtectionCountdown: React.FC<{ originalDeadlineMs: number; pausedForReview: boolean }> = ({
  originalDeadlineMs,
  pausedForReview,
}) => {
  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const remMs = computeRemainingProtectionMs(originalDeadlineMs, nowMs);
  const totalSec = Math.floor(remMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-4 gap-2 tabular-nums">
        {[
          [days, 'Days'],
          [hours, 'Hours'],
          [mins, 'Min'],
          [secs, 'Sec'],
        ].map(([val, label]) => (
          <div key={String(label)} className="p-2.5 rounded-xl bx-soft text-center">
            <strong className="block text-lg sm:text-xl font-extrabold">
              {String(val).padStart(2, '0')}
            </strong>
            <span className="text-[10px] font-extrabold uppercase" style={{ color: 'var(--text-2)' }}>
              {label}
            </span>
          </div>
        ))}
      </div>
      <p className="bx-hint">
        Immutable Original Deadline: <strong>{new Date(originalDeadlineMs).toLocaleString()}</strong>.
        {pausedForReview
          ? ' Automatic escrow release is paused while your report is under admin review — the original deadline is never extended.'
          : ' Reports, refreshes, or review pauses never extend this deadline.'}
      </p>
    </div>
  );
};

interface DealsViewProps {
  userUid: string | null;
  profile: PublicProfile | null;
  privateUser: PrivateUser | null;
  deals: DealRecord[];
  settings: PublicSettings;
  displayCurrency: CurrencyCode;
  initialDealId: string | null;
  onRequireAuth: () => void;
  onOpenWallet: () => void;
  onFlash: (msg: string) => void;
}

export const DealsView: React.FC<DealsViewProps> = ({
  userUid,
  profile,
  privateUser,
  deals,
  settings,
  displayCurrency,
  initialDealId,
  onRequireAuth,
  onOpenWallet,
  onFlash,
}) => {
  const [selectedDealId, setSelectedDealId] = useState<string | null>(initialDealId);
  const [messages, setMessages] = useState<ChatMessageRecord[]>([]);
  const [reports, setReports] = useState<DealReportRecord[]>([]);
  const [chatText, setChatText] = useState('');
  const [reportReason, setReportReason] = useState('');
  const [showReportForm, setShowReportForm] = useState(false);
  const [reviewScore, setReviewScore] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [busy, setBusy] = useState(false);
  const [errMsg, setErrMsg] = useState('');

  useEffect(() => {
    if (initialDealId) setSelectedDealId(initialDealId);
    else if (!selectedDealId && deals.length > 0) setSelectedDealId(deals[0].id);
  }, [initialDealId, deals.length]);

  const activeDeal = deals.find((d) => d.id === selectedDealId) || null;

  useEffect(() => {
    if (!activeDeal || !userUid) {
      setMessages([]);
      setReports([]);
      return;
    }
    const mq = query(collection(db, 'deals', activeDeal.id, 'messages'), orderBy('createdAt', 'asc'));
    const rq = query(collection(db, 'deals', activeDeal.id, 'reports'), orderBy('createdAt', 'desc'));

    const unsubM = onSnapshot(
      mq,
      (snap) => {
        setMessages(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              senderId: data.senderId,
              senderName: data.senderName,
              kind: data.kind || 'text',
              text: data.text || '',
              mediaData: data.mediaData,
              createdAtMs: data.createdAt?.toMillis?.() || Date.now(),
            };
          })
        );
      },
      () => {}
    );

    const unsubR = onSnapshot(
      rq,
      (snap) => {
        setReports(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              dealId: data.dealId,
              reporterId: data.reporterId,
              reporterRole: data.reporterRole,
              reason: data.reason,
              status: data.status,
              adminDecisionNote: data.adminDecisionNote,
              createdAtMs: data.createdAt?.toMillis?.() || Date.now(),
            };
          })
        );
      },
      () => {}
    );

    return () => {
      unsubM();
      unsubR();
    };
  }, [activeDeal?.id, userUid]);

  if (!userUid || !profile) {
    return (
      <div className="bx-wrap py-12">
        <div className="bx-card p-8 text-center max-w-md mx-auto space-y-3">
          <ShieldCheck className="w-10 h-10 mx-auto" style={{ color: 'var(--orange)' }} />
          <h2 className="text-xl font-extrabold">Escrow Deal Rooms</h2>
          <p className="bx-hint">
            Sign in to view your accepted bids, active escrow transfers, and buyer protection timers.
          </p>
          <button type="button" onClick={onRequireAuth} className="bx-btn bx-btn-primary">
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const isBuyer = activeDeal ? activeDeal.buyerId === userUid : false;

  const handlePayAcceptedDeal = async () => {
    if (!activeDeal || !isBuyer || !privateUser) return;
    if (privateUser.walletBalanceMinor < activeDeal.buyerTotalMinor) {
      onFlash('Insufficient wallet balance to fund this accepted deal.');
      onOpenWallet();
      return;
    }

    setBusy(true);
    setErrMsg('');
    try {
      const ledgerId = `led_pay_${activeDeal.id}`;
      await runTransaction(db, async (tx) => {
        const dealRef = doc(db, 'deals', activeDeal.id);
        const privRef = doc(db, 'privateUsers', userUid);
        const listingRef = doc(db, 'listings', activeDeal.listingId);
        const ledgerRef = doc(db, 'walletLedger', ledgerId);

        const [dSnap, pSnap] = await Promise.all([tx.get(dealRef), tx.get(privRef)]);
        if (!dSnap.exists() || dSnap.data()?.status !== 'awaiting_payment') {
          throw new Error('This deal is not awaiting payment.');
        }
        const bal = Number(pSnap.data()?.walletBalanceMinor) || 0;
        if (bal < activeDeal.buyerTotalMinor) {
          throw new Error('Insufficient wallet balance.');
        }

        tx.update(privRef, {
          walletBalanceMinor: bal - activeDeal.buyerTotalMinor,
          updatedAt: serverTimestamp(),
        });
        tx.update(dealRef, {
          status: 'awaiting_buyer_confirmation',
          updatedAt: serverTimestamp(),
        });
        tx.update(listingRef, {
          status: 'sold',
          activeDealId: activeDeal.id,
          updatedAt: serverTimestamp(),
        });
        tx.set(ledgerRef, {
          userId: userUid,
          kind: 'escrow_debit',
          amountMinor: activeDeal.buyerTotalMinor,
          currency: activeDeal.currency,
          referenceId: activeDeal.id,
          note: `Escrow funding for accepted deal ${activeDeal.id}`,
          createdAt: serverTimestamp(),
        });
      });
      const totalFmt = formatMoneyFromMinor(
        activeDeal.buyerTotalMinor,
        activeDeal.currency,
        activeDeal.currency
      );
      await Promise.all([
        emitUserNotification({
          recipientId: activeDeal.sellerId,
          eventKey: `deal_funded_seller_${activeDeal.id}`,
          category: 'deal',
          severity: 'success',
          title: 'Buyer Funded Escrow — Begin Transfer',
          preview: `${activeDeal.buyerName} funded escrow for "${activeDeal.listingTitle}".`,
          body: `${activeDeal.buyerName} has funded BEXORA Escrow (${totalFmt}) for "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}). You may now safely coordinate credential transfer inside the Deal Room.`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
        emitUserNotification({
          recipientId: userUid,
          eventKey: `deal_funded_buyer_${activeDeal.id}`,
          category: 'wallet',
          severity: 'success',
          title: 'Escrow Payment Confirmed',
          preview: `${totalFmt} locked in BEXORA Escrow for "${activeDeal.listingTitle}".`,
          body: `Your wallet payment of ${totalFmt} is safely locked in BEXORA Escrow for "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}). Coordinate handover in Deal Chat, then click "Confirm Account Received".`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
      ]);
      onFlash('Escrow payment confirmed! Coordinate handover in Deal Chat, then click Confirm Account Received.');
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Payment failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleConfirmAccountReceived = async () => {
    if (!activeDeal || !isBuyer) return;
    setBusy(true);
    setErrMsg('');
    try {
      let confirmedHours = activeDeal.protectionDurationHours;
      await runTransaction(db, async (tx) => {
        const dealRef = doc(db, 'deals', activeDeal.id);
        const dSnap = await tx.get(dealRef);
        if (!dSnap.exists()) throw new Error('Deal not found.');
        const data = dSnap.data()!;
        if (data.originalDeadlineMs > 0) {
          throw new Error('Receipt has already been confirmed and the deadline is locked.');
        }
        const nowMs = Date.now();
        const durationHours = Number(data.protectionDurationHours) || activeDeal.protectionDurationHours;
        confirmedHours = durationHours;
        const deadlineMs = nowMs + durationHours * 3_600_000;
        tx.update(dealRef, {
          status: 'protection_active',
          confirmedAtMs: nowMs,
          originalDeadlineMs: deadlineMs,
          updatedAt: serverTimestamp(),
        });
      });
      await Promise.all([
        emitUserNotification({
          recipientId: activeDeal.sellerId,
          eventKey: `deal_confirmed_seller_${activeDeal.id}`,
          category: 'deal',
          severity: 'success',
          title: 'Buyer Confirmed Asset Receipt',
          preview: `${confirmedHours}-hour protection window started for "${activeDeal.listingTitle}".`,
          body: `${activeDeal.buyerName} confirmed receiving "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}). The ${confirmedHours}-hour buyer protection countdown is now active before final payout settlement.`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
        emitUserNotification({
          recipientId: userUid,
          eventKey: `deal_confirmed_buyer_${activeDeal.id}`,
          category: 'deal',
          severity: 'info',
          title: `Buyer Protection Active (${confirmedHours}h)`,
          preview: `Protection timer started for "${activeDeal.listingTitle}".`,
          body: `You confirmed receiving "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}). Your ${confirmedHours}-hour immutable buyer protection window is active.`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
      ]);
      onFlash(`Account receipt confirmed! ${confirmedHours}-hour buyer protection timer started.`);
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Could not confirm receipt.');
    } finally {
      setBusy(false);
    }
  };

  const handleFileReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDeal) return;
    const cleanReason = reportReason.trim();
    if (cleanReason.length < 5) {
      setErrMsg('Describe the transfer or access issue clearly (at least 5 characters).');
      return;
    }

    setBusy(true);
    setErrMsg('');
    try {
      const reportRef = doc(collection(db, 'deals', activeDeal.id, 'reports'));
      await runTransaction(db, async (tx) => {
        const dealRef = doc(db, 'deals', activeDeal.id);
        const dSnap = await tx.get(dealRef);
        if (!dSnap.exists()) throw new Error('Deal not found.');
        const curCount = Number(dSnap.data()?.unresolvedReportCount) || 0;

        tx.set(reportRef, {
          dealId: activeDeal.id,
          reporterId: userUid,
          reporterRole: isBuyer ? 'buyer' : 'seller',
          reason: cleanReason,
          status: 'open',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        // Preserves confirmedAtMs and originalDeadlineMs strictly unchanged!
        tx.update(dealRef, {
          status: 'reported_under_review',
          unresolvedReportCount: curCount + 1,
          updatedAt: serverTimestamp(),
        });
      });
      const counterpartyUid = isBuyer ? activeDeal.sellerId : activeDeal.buyerId;
      await Promise.all([
        emitUserNotification({
          recipientId: counterpartyUid,
          eventKey: `deal_report_counterparty_${reportRef.id}`,
          category: 'dispute',
          severity: 'warning',
          title: 'Dispute Report Opened on Escrow Deal',
          preview: `A report was submitted for "${activeDeal.listingTitle}" — under admin review.`,
          body: `The ${isBuyer ? 'buyer' : 'seller'} submitted an issue report on "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}). Automatic escrow release is paused pending BEXORA Administrator review.`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
        emitUserNotification({
          recipientId: userUid,
          eventKey: `deal_report_self_${reportRef.id}`,
          category: 'dispute',
          severity: 'info',
          title: 'Dispute Report Submitted to Admin Review',
          preview: `Escrow release paused for "${activeDeal.listingTitle}" while under review.`,
          body: `Your report on "${activeDeal.listingTitle}" (Deal #${activeDeal.id.slice(0, 10)}) has been queued for BEXORA Administrator review. Automatic payout release is paused while your case is evaluated.`,
          refType: 'deal',
          refId: activeDeal.id,
          referenceLabel: `Deal #${activeDeal.id.slice(0, 10)}`,
          destination: `deal:${activeDeal.id}`,
        }),
      ]);
      setReportReason('');
      setShowReportForm(false);
      onFlash('Report submitted to Admin Review. Escrow auto-release is paused; original deadline remains unchanged.');
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Failed to submit report.');
    } finally {
      setBusy(false);
    }
  };

  const handleSendDealMessage = async () => {
    if (!activeDeal || !chatText.trim()) return;
    const safety = detectSensitiveOrOffPlatformContent(chatText);
    if (safety.blocked) {
      setErrMsg(safety.reason || 'Message blocked for safety.');
      return;
    }
    setBusy(true);
    setErrMsg('');
    try {
      await addDoc(collection(db, 'deals', activeDeal.id, 'messages'), {
        senderId: userUid,
        senderName: profile.displayName,
        kind: 'text',
        text: chatText.trim().slice(0, 1500),
        createdAt: serverTimestamp(),
      });
      setChatText('');
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Failed to send deal message.');
    } finally {
      setBusy(false);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDeal || !isBuyer || activeDeal.status !== 'settled') return;
    if (reviewComment.trim().length < 3) {
      setErrMsg('Write a short honest review (at least 3 characters).');
      return;
    }
    setBusy(true);
    setErrMsg('');
    try {
      const revId = `rev_${activeDeal.id}`;
      await runTransaction(db, async (tx) => {
        const revRef = doc(db, 'reviews', revId);
        const sellerPubRef = doc(db, 'publicProfiles', activeDeal.sellerId);
        const [rSnap, sSnap] = await Promise.all([tx.get(revRef), tx.get(sellerPubRef)]);
        if (rSnap.exists()) {
          throw new Error('You have already submitted a verified review for this deal.');
        }

        tx.set(revRef, {
          dealId: activeDeal.id,
          sellerId: activeDeal.sellerId,
          reviewerId: userUid,
          reviewerName: profile.displayName,
          score: reviewScore,
          comment: reviewComment.trim().slice(0, 600),
          createdAt: serverTimestamp(),
        });

        if (sSnap.exists()) {
          const curSum = Number(sSnap.data()?.ratingSum) || 0;
          const curCount = Number(sSnap.data()?.ratingCount) || 0;
          tx.update(sellerPubRef, {
            ratingSum: curSum + reviewScore,
            ratingCount: curCount + 1,
            updatedAt: serverTimestamp(),
          });
        }
      });
      setReviewComment('');
      onFlash('Verified transaction review published!');
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Could not publish review.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bx-wrap py-6">
      <div className="mb-4">
        <p className="text-xs font-extrabold uppercase tracking-wider" style={{ color: 'var(--orange)' }}>
          Protected Escrow
        </p>
        <h1 className="text-2xl font-extrabold">Your Deal Groups ({deals.length})</h1>
      </div>

      {deals.length === 0 ? (
        <div className="bx-card p-10 text-center space-y-2">
          <Clock className="w-10 h-10 mx-auto" style={{ color: 'var(--text-3)' }} />
          <h2 className="text-lg font-extrabold">No active deals yet</h2>
          <p className="bx-hint">
            Accepted bids and wallet-funded purchases open a private Escrow Deal Group here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
          {/* Deal Selector */}
          <aside className="bx-card p-3 space-y-2">
            {deals.map((d) => {
              const selected = d.id === activeDeal?.id;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => {
                    setSelectedDealId(d.id);
                    setErrMsg('');
                  }}
                  className="w-full p-3 rounded-xl text-left transition-colors space-y-1"
                  style={{
                    background: selected ? 'var(--surface-2)' : 'transparent',
                    border: selected ? '1.5px solid var(--border-strong)' : '1.5px solid transparent',
                  }}
                >
                  <div className="font-extrabold text-sm truncate">{d.listingTitle}</div>
                  <div className="flex items-center justify-between text-xs tabular-nums">
                    <span className="font-bold">
                      {formatMoneyFromMinor(d.baseAmountMinor, displayCurrency, d.currency, settings.usdToBdtRate)}
                    </span>
                    <span className="font-bold uppercase" style={{ color: 'var(--orange)' }}>
                      {d.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </button>
              );
            })}
          </aside>

          {/* Deal Room Detail */}
          {activeDeal && (
            <section className="bx-card p-5 space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b" style={{ borderColor: 'var(--border-soft)' }}>
                <div>
                  <h2 className="text-lg font-extrabold">{activeDeal.listingTitle}</h2>
                  <p className="bx-hint">
                    Buyer: <strong>{activeDeal.buyerName}</strong> · Seller: <strong>{activeDeal.sellerName}</strong>
                  </p>
                </div>
                <span className="text-xs font-extrabold uppercase px-3 py-1.5 rounded-lg bx-soft">
                  {activeDeal.status.replace(/_/g, ' ')}
                </span>
              </div>

              {errMsg && (
                <div
                  className="p-3 rounded-xl text-xs font-bold"
                  style={{ background: 'var(--red-soft)', color: 'var(--red)' }}
                  role="alert"
                >
                  {errMsg}
                </div>
              )}

              {/* Locked Financial Snapshot */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs tabular-nums">
                <div className="p-3 rounded-xl bx-soft">
                  <span className="block" style={{ color: 'var(--text-2)' }}>Accepted Base Price</span>
                  <strong className="text-sm font-extrabold">
                    {formatMoneyFromMinor(activeDeal.baseAmountMinor, displayCurrency, activeDeal.currency, settings.usdToBdtRate)}
                  </strong>
                </div>
                <div className="p-3 rounded-xl bx-soft">
                  <span className="block" style={{ color: 'var(--text-2)' }}>
                    Buyer Total (+{activeDeal.buyerFeePct}%)
                  </span>
                  <strong className="text-sm font-extrabold">
                    {formatMoneyFromMinor(activeDeal.buyerTotalMinor, displayCurrency, activeDeal.currency, settings.usdToBdtRate)}
                  </strong>
                </div>
                <div className="p-3 rounded-xl bx-soft">
                  <span className="block" style={{ color: 'var(--text-2)' }}>
                    Seller Net (-{activeDeal.sellerFeePct}%)
                  </span>
                  <strong className="text-sm font-extrabold">
                    {formatMoneyFromMinor(activeDeal.sellerPayoutMinor, displayCurrency, activeDeal.currency, settings.usdToBdtRate)}
                  </strong>
                </div>
                <div className="p-3 rounded-xl bx-soft">
                  <span className="block" style={{ color: 'var(--text-2)' }}>Protection Policy</span>
                  <strong className="text-sm font-extrabold">{activeDeal.protectionDurationHours} Hours</strong>
                </div>
              </div>

              {/* Lifecycle Controls */}
              {activeDeal.status === 'awaiting_payment' && isBuyer && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={handlePayAcceptedDeal}
                  className="bx-btn bx-btn-yellow w-full"
                >
                  Pay {formatMoneyFromMinor(activeDeal.buyerTotalMinor, displayCurrency, activeDeal.currency, settings.usdToBdtRate)} from Wallet to Activate Escrow
                </button>
              )}

              {activeDeal.status === 'awaiting_buyer_confirmation' && (
                <div className="p-4 rounded-xl bx-soft space-y-3">
                  <p className="text-sm font-bold">
                    Escrow Funded — Awaiting Asset Handover & Buyer Confirmation
                  </p>
                  <p className="bx-hint">
                    The protection timer starts only after the buyer clicks <strong>Confirm Account Received</strong> below.
                  </p>
                  {isBuyer && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={handleConfirmAccountReceived}
                      className="bx-btn bx-btn-primary w-full"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm Account Received</span>
                    </button>
                  )}
                </div>
              )}

              {activeDeal.originalDeadlineMs > 0 && (
                <ProtectionCountdown
                  originalDeadlineMs={activeDeal.originalDeadlineMs}
                  pausedForReview={activeDeal.status === 'reported_under_review'}
                />
              )}

              {/* Report Issue Workflow */}
              {(activeDeal.status === 'protection_active' || activeDeal.status === 'reported_under_review') && (
                <div className="space-y-2">
                  {!showReportForm ? (
                    <button
                      type="button"
                      onClick={() => setShowReportForm(true)}
                      className="bx-btn bx-btn-danger bx-btn-sm"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>Report an Issue (Pauses Auto-Release)</span>
                    </button>
                  ) : (
                    <form onSubmit={handleFileReport} className="p-3.5 rounded-xl bx-soft space-y-2.5">
                      <label htmlFor="deal-report-reason" className="bx-label">
                        Describe the problem for Administrator Review
                      </label>
                      <textarea
                        id="deal-report-reason"
                        rows={3}
                        value={reportReason}
                        onChange={(e) => setReportReason(e.target.value)}
                        placeholder="Explain what went wrong with the transfer or access…"
                        className="bx-textarea"
                      />
                      <div className="flex gap-2">
                        <button type="submit" disabled={busy} className="bx-btn bx-btn-danger bx-btn-sm">
                          Submit Report
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowReportForm(false)}
                          className="bx-btn bx-btn-sm"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {reports.length > 0 && (
                <div className="space-y-1.5">
                  <h3 className="text-xs font-extrabold uppercase" style={{ color: 'var(--red)' }}>
                    Submitted Reports ({reports.length})
                  </h3>
                  {reports.map((r) => (
                    <div key={r.id} className="p-3 rounded-xl text-xs space-y-1" style={{ background: 'var(--red-soft)', color: 'var(--red)' }}>
                      <div className="font-extrabold">
                        {r.reporterRole.toUpperCase()} Report · {r.status.replace(/_/g, ' ')}
                      </div>
                      <p>{r.reason}</p>
                      {r.adminDecisionNote && <p className="font-bold">Admin Note: {r.adminDecisionNote}</p>}
                    </div>
                  ))}
                </div>
              )}

              {/* Buyer Review Form after Settled Deal */}
              {activeDeal.status === 'settled' && isBuyer && (
                <form onSubmit={handleSubmitReview} className="p-4 rounded-xl bx-soft space-y-3">
                  <h3 className="text-sm font-extrabold flex items-center gap-1.5">
                    <Star className="w-4 h-4" style={{ color: 'var(--orange)' }} />
                    <span>Rate Seller for Completed Deal</span>
                  </h3>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setReviewScore(n)}
                        className="px-3 py-1.5 rounded-lg text-xs font-extrabold border"
                        style={{
                          background: reviewScore >= n ? 'var(--yellow)' : 'var(--surface)',
                          color: reviewScore >= n ? '#191919' : 'var(--text-2)',
                          borderColor: 'var(--border-soft)',
                        }}
                      >
                        {n} ★
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Share your experience with this transaction…"
                    className="bx-input"
                  />
                  <button type="submit" disabled={busy} className="bx-btn bx-btn-primary bx-btn-sm">
                    Publish Verified Review
                  </button>
                </form>
              )}

              {/* Deal Room Messages */}
              <div className="space-y-2.5 pt-2 border-t" style={{ borderColor: 'var(--border-soft)' }}>
                <h3 className="text-sm font-extrabold">Deal Group Discussion</h3>
                <div className="max-h-60 overflow-y-auto space-y-2 p-2 rounded-xl bx-soft">
                  {messages.length === 0 ? (
                    <p className="bx-hint text-center py-4">No deal messages yet.</p>
                  ) : (
                    messages.map((m) => {
                      const mine = m.senderId === userUid;
                      return (
                        <div
                          key={m.id}
                          className={`max-w-[82%] p-2.5 rounded-xl text-xs ${mine ? 'ml-auto' : 'mr-auto'}`}
                          style={{
                            background: mine ? 'var(--orange)' : 'var(--surface)',
                            color: mine ? '#FFFFFF' : 'var(--text)',
                          }}
                        >
                          <div className="font-extrabold opacity-80 mb-0.5">{m.senderName}</div>
                          <div>{m.text}</div>
                        </div>
                      );
                    })
                  )}
                </div>

                {activeDeal.status !== 'settled' &&
                  activeDeal.status !== 'refunded' &&
                  activeDeal.status !== 'cancelled' && (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={chatText}
                        onChange={(e) => setChatText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && chatText.trim()) {
                            e.preventDefault();
                            handleSendDealMessage();
                          }
                        }}
                        placeholder="Coordinate asset transfer safely…"
                        className="bx-input flex-1"
                      />
                      <button
                        type="button"
                        disabled={!chatText.trim() || busy}
                        onClick={handleSendDealMessage}
                        className="bx-btn bx-btn-primary"
                        aria-label="Send deal message"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  )}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
