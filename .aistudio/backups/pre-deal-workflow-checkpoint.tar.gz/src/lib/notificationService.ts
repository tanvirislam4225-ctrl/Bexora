import {
  collection,
  doc,
  getDoc,
  getDocs,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import {
  buildNotificationId,
  chunkForFirestoreBatch,
  isValidFirestoreDocId,
  sanitizeNotificationDestination,
  truncateNotificationField,
} from './notificationLogic';
import type {
  AnnouncementRecord,
  NotificationCategory,
  NotificationRecord,
  NotificationRefType,
  NotificationSeverity,
} from '../types';

export interface EmitNotificationInput {
  recipientId: string;
  eventKey: string;
  actorId?: string;
  actorRole?: 'user' | 'admin' | 'system';
  category: NotificationCategory;
  severity?: NotificationSeverity;
  title: string;
  preview: string;
  body: string;
  refType?: NotificationRefType;
  refId?: string;
  referenceLabel?: string;
  destination?: string;
}

const inFlightCreateIds = new Set<string>();
const inFlightMarkAllByUid = new Map<string, Promise<{ updatedCount: number }>>();

/**
 * Emits a real Firestore-backed notification idempotently AFTER the underlying marketplace action succeeds.
 * - Uses deterministic IDs (`buildNotificationId(recipientId, eventKey)`) so retries/listeners never duplicate.
 * - For self-scoped notifications (`recipientId === currentUid`), checks `getDoc` first so an existing or already-read
 *   notification is never overwritten. For cross-user counterparty notifications (`recipientId !== currentUid`),
 *   Security Rules intentionally forbid reading another user's notification doc (`get`), so we write directly via
 *   `setDoc` with deterministic ID; if already created, Firestore rejects `update` and we treat that idempotent replay cleanly.
 */
export async function emitUserNotification(
  input: EmitNotificationInput
): Promise<{ created: boolean; id: string }> {
  const currentUser = auth.currentUser;
  const recipientId = String(input.recipientId || '').trim();
  if (!currentUser || !isValidFirestoreDocId(recipientId)) {
    return { created: false, id: '' };
  }

  const actorId = String(input.actorId || currentUser.uid).trim();
  if (actorId !== currentUser.uid) {
    return { created: false, id: '' };
  }

  const notificationId = buildNotificationId(recipientId, input.eventKey);
  if (inFlightCreateIds.has(notificationId)) {
    return { created: false, id: notificationId };
  }
  inFlightCreateIds.add(notificationId);

  const safeDest = sanitizeNotificationDestination(input.destination);
  const destination = safeDest ? safeDest.raw : '';
  const refType: NotificationRefType = input.refType || 'none';
  const rawRefId = String(input.refId || '').trim();
  const refId = refType === 'none' ? '' : isValidFirestoreDocId(rawRefId) ? rawRefId : '';
  const referenceLabel = truncateNotificationField(input.referenceLabel || '', 140);
  const title = truncateNotificationField(input.title || 'BEXORA Update', 140) || 'BEXORA Update';
  const preview = truncateNotificationField(input.preview || title, 240) || title;
  const body = truncateNotificationField(input.body || preview, 2000) || preview;
  const actorRole: 'user' | 'admin' | 'system' = input.actorRole || 'user';
  const severity: NotificationSeverity = input.severity || 'info';

  const notifRef = doc(db, 'notifications', notificationId);

  try {
    if (recipientId === currentUser.uid) {
      const existingSnap = await getDoc(notifRef);
      if (existingSnap.exists()) {
        return { created: false, id: notificationId };
      }
    }

    await setDoc(notifRef, {
      recipientId,
      actorId: currentUser.uid,
      actorRole,
      category: input.category,
      severity,
      title,
      preview,
      body,
      refType: refId ? refType : 'none',
      refId: refId || '',
      referenceLabel,
      destination,
      read: false,
      createdAtMs: Date.now(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    return { created: true, id: notificationId };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    // When a cross-user deterministic notification already exists, Firestore evaluates `setDoc` as an `update`
    // by a non-recipient and rejects it. Keep non-blocking idempotency while still logging genuine errors in dev.
    if (recipientId !== currentUser.uid && msg.toLowerCase().includes('Missing or insufficient permissions'.toLowerCase())) {
      return { created: false, id: notificationId };
    }
    console.warn('[BEXORA Notifications] Non-fatal notification write skipped:', msg);
    return { created: false, id: notificationId };
  } finally {
    inFlightCreateIds.delete(notificationId);
  }
}

/**
 * Marks a single notification belonging to `currentUid` as read in Firestore.
 */
export async function markNotificationReadInFirestore(
  notification: Pick<NotificationRecord, 'id' | 'recipientId' | 'read'>
): Promise<boolean> {
  const currentUser = auth.currentUser;
  if (!currentUser || !notification || notification.recipientId !== currentUser.uid) {
    return false;
  }
  if (notification.read) {
    return true;
  }
  const path = `notifications/${notification.id}`;
  try {
    await updateDoc(doc(db, 'notifications', notification.id), {
      read: true,
      readAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return false;
  }
}

/**
 * Marks all unread notifications belonging ONLY to `uid` as read using safe chunked Firestore `writeBatch`
 * (`<= 450` writes per batch) and an in-flight per-user lock to prevent duplicate batch races.
 */
export async function markAllNotificationsReadInFirestore(
  uid: string,
  notifications: ReadonlyArray<NotificationRecord>
): Promise<{ updatedCount: number }> {
  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) {
    throw new Error('You must be signed in to update your notifications.');
  }

  const existingInFlight = inFlightMarkAllByUid.get(uid);
  if (existingInFlight) {
    return existingInFlight;
  }

  const job = (async () => {
    const eligibleUnread = notifications.filter(
      (item) =>
        item &&
        item.recipientId === uid &&
        item.read === false &&
        !item.isAnnouncementMirror &&
        isValidFirestoreDocId(item.id)
    );

    if (eligibleUnread.length === 0) {
      return { updatedCount: 0 };
    }

    const chunks = chunkForFirestoreBatch(eligibleUnread, 450);
    let updatedCount = 0;

    for (const chunk of chunks) {
      const batch = writeBatch(db);
      for (const item of chunk) {
        batch.update(doc(db, 'notifications', item.id), {
          read: true,
          readAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      try {
        await batch.commit();
        updatedCount += chunk.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, 'notifications');
      }
    }

    return { updatedCount };
  })();

  inFlightMarkAllByUid.set(uid, job);
  try {
    return await job;
  } finally {
    inFlightMarkAllByUid.delete(uid);
  }
}

export interface PublishAdminNotificationInput {
  mode: 'broadcast_announcement' | 'targeted_user';
  targetUid?: string;
  category: NotificationCategory;
  severity: NotificationSeverity;
  title: string;
  preview: string;
  body: string;
  destination?: string;
  persistPublicBanner?: boolean;
}

/**
 * Admin-only publisher:
 * - For `broadcast_announcement`: creates `/announcements/{announcementId}` (if `persistPublicBanner`)
 *   AND fans out individual `/notifications/{id}` records in chunked batches (`<= 450`) to registered users
 *   so every user gets durable personal read/unread tracking.
 * - For `targeted_user`: delivers a direct `/notifications/{id}` record to `targetUid`.
 */
export async function publishAdminNotification(
  input: PublishAdminNotificationInput
): Promise<{ announcementId?: string; deliveredCount: number }> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('Administrator sign-in required.');
  }

  const safeDest = sanitizeNotificationDestination(input.destination);
  const destination = safeDest ? safeDest.raw : '';
  const title = truncateNotificationField(input.title, 140);
  const preview = truncateNotificationField(input.preview || input.body, 240);
  const body = truncateNotificationField(input.body, 2000);
  if (!title || !body) {
    throw new Error('Notification title and full message are required.');
  }

  const nowMs = Date.now();

  if (input.mode === 'targeted_user') {
    const targetUid = String(input.targetUid || '').trim();
    if (!isValidFirestoreDocId(targetUid)) {
      throw new Error('Enter a valid target User UID.');
    }
    const notifId = buildNotificationId(targetUid, `admin_direct_${nowMs}_${title.slice(0, 20)}`);
    try {
      await setDoc(doc(db, 'notifications', notifId), {
        recipientId: targetUid,
        actorId: currentUser.uid,
        actorRole: 'admin',
        category: input.category,
        severity: input.severity,
        title,
        preview: preview || title,
        body,
        refType: 'none',
        refId: '',
        referenceLabel: 'Administrator Notice',
        destination,
        read: false,
        createdAtMs: nowMs,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return { deliveredCount: 1 };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `notifications/${notifId}`);
      return { deliveredCount: 0 };
    }
  }

  const announcementId = `ann_${nowMs}_${Math.random().toString(36).slice(2, 8)}`;
  if (input.persistPublicBanner !== false) {
    try {
      await setDoc(doc(db, 'announcements', announcementId), {
        title,
        preview: preview || title,
        body,
        severity: input.severity,
        destination,
        active: true,
        authorId: currentUser.uid,
        createdAtMs: nowMs,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `announcements/${announcementId}`);
    }
  }

  let recipientUids: string[] = [];
  try {
    const profilesSnap = await getDocs(collection(db, 'publicProfiles'));
    recipientUids = profilesSnap.docs
      .map((d) => d.id)
      .filter((uid) => isValidFirestoreDocId(uid));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'publicProfiles');
  }

  if (recipientUids.length === 0) {
    recipientUids = [currentUser.uid];
  }

  const chunks = chunkForFirestoreBatch(recipientUids, 450);
  let deliveredCount = 0;

  for (const chunk of chunks) {
    const batch = writeBatch(db);
    for (const uid of chunk) {
      const notifId = buildNotificationId(uid, `announcement_${announcementId}`);
      batch.set(doc(db, 'notifications', notifId), {
        recipientId: uid,
        actorId: currentUser.uid,
        actorRole: 'admin',
        category: 'announcement',
        severity: input.severity,
        title,
        preview: preview || title,
        body,
        refType: input.persistPublicBanner !== false ? 'announcement' : 'none',
        refId: input.persistPublicBanner !== false ? announcementId : '',
        referenceLabel: 'BEXORA Announcement',
        destination,
        read: false,
        createdAtMs: nowMs,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    try {
      await batch.commit();
      deliveredCount += chunk.length;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'notifications');
    }
  }

  return { announcementId, deliveredCount };
}

export async function archiveAdminAnnouncement(announcementId: string): Promise<void> {
  if (!isValidFirestoreDocId(announcementId)) return;
  try {
    await updateDoc(doc(db, 'announcements', announcementId), {
      active: false,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `announcements/${announcementId}`);
  }
}

const LOCAL_ANNOUNCEMENT_READ_STORAGE_KEY = 'bexora_read_announcements_v1';

export function getLocallyReadAnnouncementIds(scopeKey: string): Set<string> {
  try {
    const raw = localStorage.getItem(`${LOCAL_ANNOUNCEMENT_READ_STORAGE_KEY}:${scopeKey}`);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.filter((x) => typeof x === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

export function markLocalAnnouncementRead(scopeKey: string, announcementId: string): void {
  try {
    const current = getLocallyReadAnnouncementIds(scopeKey);
    current.add(announcementId);
    localStorage.setItem(
      `${LOCAL_ANNOUNCEMENT_READ_STORAGE_KEY}:${scopeKey}`,
      JSON.stringify(Array.from(current).slice(-200))
    );
  } catch {
    // Ignore storage quota issues in restricted browsers
  }
}

/**
 * Merges active `/announcements` that do not yet have a personal `/notifications` copy (for example,
 * for guests or newly registered accounts created after a broadcast) into the display feed cleanly.
 */
export function mergeAnnouncementsIntoFeed(
  personalNotifications: ReadonlyArray<NotificationRecord>,
  activeAnnouncements: ReadonlyArray<AnnouncementRecord>,
  viewerUid: string | null
): NotificationRecord[] {
  const existingAnnouncementRefs = new Set(
    personalNotifications
      .filter((n) => n.refType === 'announcement' && n.refId)
      .map((n) => n.refId)
  );
  const scopeKey = viewerUid || 'guest';
  const locallyReadIds = getLocallyReadAnnouncementIds(scopeKey);

  const syntheticMirrors: NotificationRecord[] = activeAnnouncements
    .filter((ann) => ann.active && !existingAnnouncementRefs.has(ann.id))
    .map((ann) => ({
      id: `ann_mirror_${ann.id}`,
      recipientId: viewerUid || 'guest',
      actorId: ann.authorId,
      actorRole: 'admin',
      category: 'announcement',
      severity: ann.severity,
      title: ann.title,
      preview: ann.preview,
      body: ann.body,
      refType: 'announcement',
      refId: ann.id,
      referenceLabel: 'Platform Announcement',
      destination: ann.destination || '',
      read: locallyReadIds.has(ann.id),
      createdAtMs: ann.createdAtMs,
      isAnnouncementMirror: true,
    }));

  return [...personalNotifications, ...syntheticMirrors].sort(
    (a, b) => (Number(b.createdAtMs) || 0) - (Number(a.createdAtMs) || 0)
  );
}
