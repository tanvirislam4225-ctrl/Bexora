import { deleteDoc, doc, getDocs, collection, serverTimestamp, setDoc } from 'firebase/firestore';
import { deleteToken, getMessaging, getToken, isSupported, onMessage, type MessagePayload } from 'firebase/messaging';
import app, { auth, db } from './firebase';
import { deterministicHashHex } from './notificationLogic';

export type WebPushStatus =
  | 'unsupported'
  | 'signed_out'
  | 'permission_denied'
  | 'vapid_key_missing'
  | 'ready_to_enable'
  | 'enabled';

export interface WebPushStateSnapshot {
  status: WebPushStatus;
  permission: NotificationPermission | 'unsupported';
  vapidConfigured: boolean;
  activeTokenCount: number;
  detailMessage: string;
}

const PUSH_SW_PATH = '/firebase-messaging-sw.js';

function getConfiguredVapidKey(): string {
  const raw = String(import.meta.env.VITE_FIREBASE_VAPID_KEY || '').trim();
  if (!raw || raw === 'YOUR_FIREBASE_VAPID_KEY' || raw === 'MY_FIREBASE_VAPID_KEY') {
    return '';
  }
  return raw;
}

export async function inspectWebPushState(uid: string | null): Promise<WebPushStateSnapshot> {
  if (typeof window === 'undefined' || !('Notification' in window) || !('serviceWorker' in navigator)) {
    return {
      status: 'unsupported',
      permission: 'unsupported',
      vapidConfigured: Boolean(getConfiguredVapidKey()),
      activeTokenCount: 0,
      detailMessage: 'Browser push notifications are not supported in this browser or embedded frame.',
    };
  }

  const messagingSupported = await isSupported().catch(() => false);
  if (!messagingSupported) {
    return {
      status: 'unsupported',
      permission: Notification.permission,
      vapidConfigured: Boolean(getConfiguredVapidKey()),
      activeTokenCount: 0,
      detailMessage: 'Firebase Cloud Messaging Web Push APIs are unavailable in this browser context.',
    };
  }

  const vapidKey = getConfiguredVapidKey();
  const permission = Notification.permission;

  if (!uid) {
    return {
      status: 'signed_out',
      permission,
      vapidConfigured: Boolean(vapidKey),
      activeTokenCount: 0,
      detailMessage: 'Sign in to manage browser push notifications for your BEXORA account.',
    };
  }

  if (permission === 'denied') {
    return {
      status: 'permission_denied',
      permission,
      vapidConfigured: Boolean(vapidKey),
      activeTokenCount: 0,
      detailMessage:
        'Browser notification permission is blocked. Allow notifications in your browser site settings to enable push alerts. In-app notifications remain active.',
    };
  }

  let activeTokenCount = 0;
  try {
    const snap = await getDocs(collection(db, 'privateUsers', uid, 'pushTokens'));
    activeTokenCount = snap.docs.filter((d) => d.data()?.enabled === true).length;
  } catch {
    activeTokenCount = 0;
  }

  if (!vapidKey) {
    return {
      status: 'vapid_key_missing',
      permission,
      vapidConfigured: false,
      activeTokenCount,
      detailMessage:
        'In-app real-time notifications are active. Browser Web Push awaits a Firebase Cloud Messaging Web Push certificate key (VITE_FIREBASE_VAPID_KEY).',
    };
  }

  if (permission === 'granted' && activeTokenCount > 0) {
    return {
      status: 'enabled',
      permission,
      vapidConfigured: true,
      activeTokenCount,
      detailMessage: 'Browser push notifications are enabled for this device.',
    };
  }

  return {
    status: 'ready_to_enable',
    permission,
    vapidConfigured: true,
    activeTokenCount,
    detailMessage: 'Enable browser push alerts for bids, escrow milestones, and security updates.',
  };
}

/**
 * Explicitly triggered ONLY by a direct user click inside the Notification Center.
 * Never runs automatically on page load.
 */
export async function enableWebPushForCurrentUser(): Promise<{
  ok: boolean;
  status: WebPushStatus;
  message: string;
}> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    return { ok: false, status: 'signed_out', message: 'Sign in first to enable push notifications.' };
  }

  if (typeof window === 'undefined' || !('Notification' in window) || !('serviceWorker' in navigator)) {
    return {
      ok: false,
      status: 'unsupported',
      message: 'This browser does not support Web Push notifications. Real-time in-app notifications remain active.',
    };
  }

  const supported = await isSupported().catch(() => false);
  if (!supported) {
    return {
      ok: false,
      status: 'unsupported',
      message: 'Firebase Cloud Messaging is unsupported in this browser environment.',
    };
  }

  const vapidKey = getConfiguredVapidKey();
  if (!vapidKey) {
    return {
      ok: false,
      status: 'vapid_key_missing',
      message:
        'VITE_FIREBASE_VAPID_KEY is not configured yet. Add your Firebase Cloud Messaging Web Push key pair in Project Settings > Cloud Messaging to issue browser push tokens.',
    };
  }

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    return {
      ok: false,
      status: 'permission_denied',
      message: 'Notification permission was not granted. In-app notifications continue working normally.',
    };
  }

  try {
    const swReg = await navigator.serviceWorker.register(PUSH_SW_PATH, { scope: '/' });
    await navigator.serviceWorker.ready;
    const messaging = getMessaging(app);
    const fcmToken = await getToken(messaging, {
      vapidKey,
      serviceWorkerRegistration: swReg,
    });

    if (!fcmToken) {
      return {
        ok: false,
        status: 'ready_to_enable',
        message: 'Could not retrieve an FCM registration token at this time. Please retry shortly.',
      };
    }

    const tokenId = `fcm_${deterministicHashHex(fcmToken)}`;
    await setDoc(doc(db, 'privateUsers', currentUser.uid, 'pushTokens', tokenId), {
      uid: currentUser.uid,
      token: fcmToken,
      userAgent: String(navigator.userAgent || 'Browser').slice(0, 240),
      enabled: true,
      createdAtMs: Date.now(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    return {
      ok: true,
      status: 'enabled',
      message: 'Browser push notifications enabled for this device.',
    };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return {
      ok: false,
      status: 'ready_to_enable',
      message: `Unable to register Web Push token: ${detail.slice(0, 160)}`,
    };
  }
}

/**
 * Revokes FCM registration token and removes per-user push token docs for the signed-in user.
 */
export async function disableWebPushForCurrentUser(): Promise<{ ok: boolean; message: string }> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    return { ok: false, message: 'Sign in required.' };
  }

  try {
    const supported = await isSupported().catch(() => false);
    if (supported) {
      const messaging = getMessaging(app);
      await deleteToken(messaging).catch(() => false);
    }

    const snap = await getDocs(collection(db, 'privateUsers', currentUser.uid, 'pushTokens'));
    for (const tokenDoc of snap.docs) {
      await deleteDoc(doc(db, 'privateUsers', currentUser.uid, 'pushTokens', tokenDoc.id));
    }

    return { ok: true, message: 'Browser push notifications disabled for your account on this device.' };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return { ok: false, message: `Could not remove push subscription: ${detail.slice(0, 140)}` };
  }
}

/**
 * Attaches foreground FCM listener when supported and permission is already granted.
 */
export function subscribeForegroundPushMessages(
  onForegroundPayload: (payload: MessagePayload) => void
): () => void {
  let unsub: (() => void) | null = null;
  let cancelled = false;

  if (typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') {
    return () => {};
  }
  if (!getConfiguredVapidKey()) {
    return () => {};
  }

  isSupported()
    .then((supported) => {
      if (!supported || cancelled) return;
      const messaging = getMessaging(app);
      unsub = onMessage(messaging, (payload) => {
        onForegroundPayload(payload);
      });
    })
    .catch(() => {
      // Non-fatal in environments without PushManager
    });

  return () => {
    cancelled = true;
    if (unsub) unsub();
  };
}
